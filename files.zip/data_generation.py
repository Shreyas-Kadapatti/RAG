"""
data_generation.py
==================
Generates a synthetic Customer Lifetime Value (CLV) dataset with 100,000+ rows.
Realistic relationships are baked in:
  - Higher income → higher spend
  - Longer tenure → higher frequency
  - Younger customers prefer online channels
"""

import numpy as np
import pandas as pd
from pathlib import Path

# ── Reproducibility ──────────────────────────────────────────────────────────
SEED = 42
np.random.seed(SEED)

# ── Constants ────────────────────────────────────────────────────────────────
N_CUSTOMERS = 100_000
CHANNELS     = ["Online", "In-Store", "Mobile", "Phone"]
OUTPUT_PATH  = Path("data/customers.csv")


def generate_dataset(n: int = N_CUSTOMERS) -> pd.DataFrame:
    """Create a DataFrame with realistic CLV-relevant features."""

    # ── Demographics ─────────────────────────────────────────────────────────
    age    = np.random.randint(18, 75, n)
    income = np.clip(
        np.random.normal(60_000, 25_000, n) + (age - 18) * 300,   # older → richer
        10_000, 300_000
    ).astype(int)

    # ── Tenure (months with the company) ────────────────────────────────────
    tenure = np.random.randint(1, 121, n)          # 1–120 months

    # ── Frequency (purchases per month) depends on tenure ───────────────────
    frequency = np.clip(
        np.random.poisson(lam=2 + tenure / 40, size=n),
        1, 30
    )

    # ── Monthly Spend: income-driven + noise ─────────────────────────────────
    spend_base = (income / 12) * np.random.uniform(0.03, 0.18, n)
    spend      = np.clip(
        spend_base * (1 + frequency * 0.05) + np.random.normal(0, 50, n),
        10, 15_000
    ).round(2)

    # ── Channel: younger customers lean Online / Mobile ──────────────────────
    channel_probs = []
    for a in age:
        if a < 35:
            channel_probs.append([0.45, 0.15, 0.35, 0.05])
        elif a < 55:
            channel_probs.append([0.30, 0.35, 0.25, 0.10])
        else:
            channel_probs.append([0.15, 0.50, 0.10, 0.25])
    channels = [
        np.random.choice(CHANNELS, p=p) for p in channel_probs
    ]

    # ── Recency (days since last purchase) ────────────────────────────────────
    # High-frequency customers bought more recently on average
    recency = np.clip(
        np.random.exponential(scale=30 / frequency) + 1,
        1, 365
    ).astype(int)

    # ── CLV (target): tenure × avg monthly spend × frequency factor ──────────
    # A simplified but realistic formula; add noise so models must work
    clv = (
        spend * frequency * (tenure / 12) * np.random.uniform(0.8, 1.2, n)
    ).round(2)

    # ── Introduce realistic missing values (~2%) ─────────────────────────────
    for col_arr in [income, spend, frequency]:
        mask = np.random.random(n) < 0.02
        col_arr = col_arr.astype(float)
        col_arr[mask] = np.nan

    # ── Assemble DataFrame ────────────────────────────────────────────────────
    df = pd.DataFrame({
        "CustomerID": [f"CUST{i:06d}" for i in range(1, n + 1)],
        "Age":        age,
        "Income":     income.astype(float),
        "Spend":      spend,
        "Frequency":  frequency.astype(float),
        "Tenure":     tenure,
        "Channel":    channels,
        "Recency":    recency,
        "CLV":        clv,
    })

    # Re-inject NaNs properly
    for col in ["Income", "Spend", "Frequency"]:
        mask = np.random.random(n) < 0.02
        df.loc[mask, col] = np.nan

    return df


def main():
    print("⚙️  Generating synthetic CLV dataset …")
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    df = generate_dataset()
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"✅  Saved {len(df):,} rows → {OUTPUT_PATH}")
    print(df.describe().round(2))
    return df


if __name__ == "__main__":
    main()
