# 💎 AI Customer Lifetime Value (CLV) & Personalization Engine

A complete end-to-end ML system for predicting CLV, segmenting customers,
generating personalised offers, and answering business questions via a GenAI chatbot.

---

## 📁 Folder Structure

```
clv_engine/
│
├── data_generation.py   # Generate synthetic 100K+ customer dataset
├── preprocessing.py     # Clean, encode, scale, feature-engineer
├── model.py             # Train Linear Regression / Random Forest / XGBoost
├── clustering.py        # K-Means segmentation + business insights
├── chatbot.py           # RAG chatbot (FAISS + Sentence Transformers + Claude/OpenAI)
├── app.py               # Streamlit dashboard (all-in-one UI)
│
├── requirements.txt
├── README.md
│
├── data/                # Auto-created
│   ├── customers.csv        ← raw synthetic data
│   └── customers_clean.csv  ← after preprocessing
│
├── models/              # Auto-created
│   ├── scaler.pkl
│   ├── linear_regression.pkl
│   ├── random_forest.pkl
│   ├── xgboost.pkl
│   ├── best_model.pkl
│   └── kmeans.pkl
│
└── outputs/             # Auto-created
    ├── model_comparison.png
    └── clusters.png
```

---

## 🚀 Quick Start

### 1. Clone / download the project
```bash
git clone <your-repo-url>
cd clv_engine
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

> ⚠️  `faiss-cpu` can be slow to install on Windows. If it fails, try:
> `pip install faiss-cpu --no-build-isolation`

### 4. (Optional) Set API keys for the GenAI chatbot
```bash
# Mac/Linux
export ANTHROPIC_API_KEY="sk-ant-..."    # Claude (recommended)
export OPENAI_API_KEY="sk-..."           # GPT fallback

# Windows PowerShell
$env:ANTHROPIC_API_KEY="sk-ant-..."
```
> The chatbot works without API keys using built-in rule-based answers.

### 5. Launch the Streamlit dashboard
```bash
streamlit run app.py
```

The app opens at **http://localhost:8501**

---

## 🎮 Using the Dashboard

| Tab | What to do |
|-----|-----------|
| 📂 Data | Click **Generate Dataset** or upload your own CSV |
| (sidebar) | Click **🚀 Generate & Run Pipeline** to train everything |
| 📊 Predictions | View model comparison, RMSE/R², feature importance |
| 🔵 Segments | Explore customer clusters and the PCA scatter plot |
| 💡 Insights | Read auto-generated business insights |
| 🎁 Offers | Look up personalised offers per customer |
| 🤖 Chatbot | Ask natural-language questions about your customers |

---

## 🧪 Run Individual Scripts (without Streamlit)

```bash
# 1. Generate data
python data_generation.py

# 2. Preprocess
python preprocessing.py

# 3. Train models
python model.py

# 4. Cluster & insights
python clustering.py

# 5. Chatbot smoke-test
python chatbot.py
```

---

## 📊 Sample Outputs

### Model Comparison (example)
| Model             |   RMSE   |   R²   |
|-------------------|----------|--------|
| XGBoost           |  1,240   | 0.9412 |
| Random Forest     |  1,580   | 0.9107 |
| Linear Regression |  3,920   | 0.7231 |

### Segment Distribution (example)
| Segment       | Customers | Avg CLV  |
|---------------|-----------|----------|
| High Value    |  15,200   | $18,400  |
| Medium Value  |  42,100   |  $5,800  |
| Low Value     |  42,700   |  $1,200  |

### Chatbot Q&A
```
Q: Who are the top customers?
A: Top 5 customers by CLV:
   • CUST042310: $48,200 (High Value)
   • CUST087654: $45,900 (High Value)
   ...

Q: How can we improve retention?
A: 3,200 high-value customers haven't purchased in 90+ days.
   Recommend win-back campaigns with premium offers.
   Medium-value customers respond well to loyalty reward upgrades.
```

---

## 🔧 Customisation

- **Add more models**: Edit `model.py → build_models()` dict
- **Change features**: Edit `preprocessing.py → FEATURE_COLS`
- **Custom offers**: Edit `clustering.py → offer_map`
- **More chatbot context**: Add chunks to `chatbot.py → _build_knowledge_base()`

---

## 📦 Tech Stack

| Layer | Library |
|-------|---------|
| Data | pandas, numpy |
| ML | scikit-learn, XGBoost |
| RAG | FAISS, sentence-transformers |
| LLM | Anthropic Claude / OpenAI GPT |
| Dashboard | Streamlit |
| Viz | matplotlib |
