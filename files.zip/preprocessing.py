"""
preprocessing.py
================
Handles:
  1. Loading raw data
  2. Missing-value imputation
  3. Categorical encoding
  4. Feature engineering (RFM, monthly spend, etc.)
  5. Scaling / normalisation
  6. Train/test split
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
import joblib

# ── Paths ────────────────────────────────────────────────────────────────────
RAW_PATH    = Path("data/customers.csv")
CLEAN_PATH  = Path("data/customers_clean.csv")
SCALER_PATH = Path("models/scaler.pkl")


# ─────────────────────────────────────────────────────────────────────────────
def load_data(path: Path = RAW_PATH) -> pd.DataFrame:
    """Load raw CSV."""
    df = pd.read_csv(path)
    print(f"📂  Loaded {len(df):,} rows, {df.shape[1]} columns")
    return df


# ─────────────────────────────────────────────────────────────────────────────
def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    """Impute numeric NaNs with median; drop rows still missing after impute."""
    numeric_cols = df.select_dtypes(include="number").columns
    before = df.isna().sum().sum()
    for col in numeric_cols:
        if df[col].isna().any():
            median_val = df[col].median()
            df[col].fillna(median_val, inplace=True)
    after = df.isna().sum().sum()
    print(f"🩹  Missing values: {before} → {after}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """Label-encode the Channel column."""
    le = LabelEncoder()
    df["Channel_Code"] = le.fit_transform(df["Channel"])
    print(f"🔤  Encoded 'Channel' → 'Channel_Code'  ({dict(zip(le.classes_, le.transform(le.classes_)))})")
    return df


# ─────────────────────────────────────────────────────────────────────────────
def feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create derived features:
      - MonthlySpend   : Spend × Frequency  (total monthly outlay)
      - SpendIncomePct : Spend / Income      (spend-to-income ratio)
      - TenureYears    : Tenure / 12
      - RFM_Score      : Recency + Frequency + MonthlySpend (normalised composite)
    """
    df["MonthlySpend"]    = (df["Spend"] * df["Frequency"]).round(2)
    df["SpendIncomePct"]  = (df["Spend"] / df["Income"]).round(4)
    df["TenureYears"]     = (df["Tenure"] / 12).round(2)

    # RFM: lower recency = better, so invert it
    r_score = 1 / (df["Recency"] + 1)           # recency score (0-1)
    f_score = df["Frequency"] / df["Frequency"].max()
    m_score = df["MonthlySpend"] / df["MonthlySpend"].max()
    df["RFM_Score"] = ((r_score + f_score + m_score) / 3).round(4)

    print("🔧  Feature engineering complete: MonthlySpend, SpendIncomePct, TenureYears, RFM_Score")
    return df


# ─────────────────────────────────────────────────────────────────────────────
FEATURE_COLS = [
    "Age", "Income", "Spend", "Frequency", "Tenure",
    "Recency", "Channel_Code", "MonthlySpend",
    "SpendIncomePct", "TenureYears", "RFM_Score",
]
TARGET_COL = "CLV"


def scale_features(df: pd.DataFrame, fit: bool = True):
    """
    MinMax-scale the feature columns.
    Returns (X_scaled DataFrame, y Series, fitted scaler).
    Pass fit=False to transform only (for inference).
    """
    X = df[FEATURE_COLS].copy()
    y = df[TARGET_COL].copy()

    scaler = MinMaxScaler()
    if fit:
        X_scaled = scaler.fit_transform(X)
        SCALER_PATH.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(scaler, SCALER_PATH)
        print(f"💾  Scaler saved → {SCALER_PATH}")
    else:
        scaler = joblib.load(SCALER_PATH)
        X_scaled = scaler.transform(X)

    X_df = pd.DataFrame(X_scaled, columns=FEATURE_COLS, index=df.index)
    return X_df, y, scaler


# ─────────────────────────────────────────────────────────────────────────────
def run_pipeline(path: Path = RAW_PATH):
    """Full preprocessing pipeline → returns train/test splits."""
    df = load_data(path)
    df = handle_missing(df)
    df = encode_categoricals(df)
    df = feature_engineering(df)

    # Save clean dataset
    CLEAN_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(CLEAN_PATH, index=False)
    print(f"✅  Clean dataset saved → {CLEAN_PATH}")

    X, y, scaler = scale_features(df, fit=True)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    print(f"✂️   Train: {len(X_train):,} | Test: {len(X_test):,}")
    return X_train, X_test, y_train, y_test, df, scaler


if __name__ == "__main__":
    run_pipeline()
