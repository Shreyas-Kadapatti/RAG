"""
chatbot.py
==========
GenAI RAG Chatbot using:
  - FAISS vector store  (in-process, no server needed)
  - Sentence-Transformers for embeddings  (free, local)
  - Anthropic Claude API  (primary) with OpenAI fallback
  - Pre-built knowledge base from dataset insights

The chatbot answers questions like:
  "Who are the top customers?"
  "How can we improve retention?"
  "Which segment is most profitable?"
"""

import os
import json
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional

# ── Optional heavy imports (graceful fallback) ─────────────────────────────
try:
    import faiss
    from sentence_transformers import SentenceTransformer
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
class CLVChatbot:
    """
    RAG-based chatbot for CLV insights.

    Architecture:
      1. Build a knowledge base (list of text chunks) from the dataset
      2. Embed chunks with a local sentence-transformer model
      3. Index embeddings with FAISS
      4. At query time: embed query → retrieve top-k chunks → send to LLM
    """

    def __init__(self, df: Optional[pd.DataFrame] = None, insights: Optional[list] = None):
        self.df       = df
        self.insights = insights or []
        self.chunks   = []
        self.index    = None
        self.encoder  = None
        self._ready   = False

        if FAISS_AVAILABLE and df is not None:
            self._build_knowledge_base()
            self._build_faiss_index()
            self._ready = True
            print("🤖  Chatbot RAG engine ready")
        else:
            print("ℹ️   Chatbot running in simple mode (FAISS not installed or no data)")

    # ── Knowledge Base ────────────────────────────────────────────────────────
    def _build_knowledge_base(self):
        df = self.df
        chunks = []

        # General stats
        chunks.append(
            f"The dataset contains {len(df):,} customers. "
            f"Average CLV is ${df['CLV'].mean():,.2f}. "
            f"Median CLV is ${df['CLV'].median():,.2f}."
        )

        # Segment stats
        for seg in df["Segment"].unique():
            sub = df[df["Segment"] == seg]
            chunks.append(
                f"The {seg} segment has {len(sub):,} customers. "
                f"Their average CLV is ${sub['CLV'].mean():,.2f}, "
                f"average monthly spend is ${sub['MonthlySpend'].mean():,.2f}, "
                f"and average tenure is {sub['Tenure'].mean():.1f} months. "
                f"Recommended offer: {sub['Offer'].iloc[0]}."
            )

        # Top customers
        top10 = df.nlargest(10, "CLV")[["CustomerID", "CLV", "Segment", "Channel"]]
        for _, row in top10.iterrows():
            chunks.append(
                f"Top customer {row['CustomerID']} has a CLV of ${row['CLV']:,.2f}, "
                f"belongs to the {row['Segment']} segment, and uses the {row['Channel']} channel."
            )

        # Channel analysis
        ch_stats = df.groupby("Channel")["CLV"].mean().sort_values(ascending=False)
        for ch, val in ch_stats.items():
            chunks.append(f"The {ch} channel has an average CLV of ${val:,.2f}.")

        # Retention insight
        at_risk = df[(df["Recency"] > 90) & (df["Segment"] == "High Value")]
        chunks.append(
            f"There are {len(at_risk):,} high-value customers who haven't purchased in over 90 days. "
            "These are at-risk customers who should receive priority re-engagement campaigns."
        )

        # Retention strategies
        chunks.append(
            "To improve customer retention: (1) Identify high-value customers with high recency and "
            "send personalised win-back emails. (2) Offer loyalty rewards to medium-value customers "
            "to upgrade them. (3) Use seasonal discounts for low-value customers to increase frequency. "
            "(4) Focus on the top-performing channel for each segment."
        )

        # Add pre-computed insights
        for ins in self.insights:
            # Strip markdown bold markers for cleaner embedding
            chunks.append(ins.replace("**", "").replace("📌", "").replace("📡", "")
                             .replace("🎂", "").replace("💎", "").replace("⚠️", "")
                             .replace("📈", ""))

        self.chunks = chunks
        print(f"📚  Knowledge base: {len(chunks)} chunks built")

    # ── FAISS Index ───────────────────────────────────────────────────────────
    def _build_faiss_index(self):
        print("🔢  Building FAISS index with sentence embeddings …")
        self.encoder = SentenceTransformer("all-MiniLM-L6-v2")
        embeddings   = self.encoder.encode(self.chunks, show_progress_bar=False)
        embeddings   = np.array(embeddings, dtype="float32")
        faiss.normalize_L2(embeddings)

        dim         = embeddings.shape[1]
        self.index  = faiss.IndexFlatIP(dim)   # inner product = cosine after L2 norm
        self.index.add(embeddings)
        print(f"✅  FAISS index: {self.index.ntotal} vectors (dim={dim})")

    # ── Retrieval ─────────────────────────────────────────────────────────────
    def _retrieve(self, query: str, top_k: int = 5) -> str:
        if not self._ready:
            return ""
        q_emb = self.encoder.encode([query], show_progress_bar=False)
        q_emb = np.array(q_emb, dtype="float32")
        faiss.normalize_L2(q_emb)
        _, ids = self.index.search(q_emb, top_k)
        retrieved = [self.chunks[i] for i in ids[0] if i < len(self.chunks)]
        return "\n\n".join(retrieved)

    # ── LLM Call ──────────────────────────────────────────────────────────────
    def _call_llm(self, system: str, user: str) -> str:
        """Try Anthropic Claude first, then OpenAI, then return fallback."""

        # ── Anthropic ────────────────────────────────────────────────────────
        if ANTHROPIC_AVAILABLE:
            api_key = os.getenv("ANTHROPIC_API_KEY", "")
            if api_key:
                try:
                    client = anthropic.Anthropic(api_key=api_key)
                    msg    = client.messages.create(
                        model="claude-opus-4-5",
                        max_tokens=512,
                        system=system,
                        messages=[{"role": "user", "content": user}],
                    )
                    return msg.content[0].text
                except Exception as e:
                    print(f"⚠️  Anthropic error: {e}")

        # ── OpenAI ───────────────────────────────────────────────────────────
        if OPENAI_AVAILABLE:
            api_key = os.getenv("OPENAI_API_KEY", "")
            if api_key:
                try:
                    openai.api_key = api_key
                    resp = openai.chat.completions.create(
                        model="gpt-3.5-turbo",
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user",   "content": user},
                        ],
                        max_tokens=512,
                    )
                    return resp.choices[0].message.content
                except Exception as e:
                    print(f"⚠️  OpenAI error: {e}")

        # ── Local fallback ────────────────────────────────────────────────────
        return self._local_answer(user)

    # ── Rule-based Fallback ───────────────────────────────────────────────────
    def _local_answer(self, query: str) -> str:
        """Simple keyword-based answers when no LLM API key is available."""
        q = query.lower()

        if self.df is not None:
            df = self.df

            if any(kw in q for kw in ["top customer", "best customer", "highest clv"]):
                top = df.nlargest(5, "CLV")[["CustomerID", "CLV", "Segment"]]
                rows = "\n".join(f"  • {r.CustomerID}: ${r.CLV:,.0f} ({r.Segment})" for _, r in top.iterrows())
                return f"🏆 Top 5 customers by CLV:\n{rows}"

            if any(kw in q for kw in ["retention", "churn", "keep customer"]):
                at_risk = df[(df["Recency"] > 90) & (df["Segment"] == "High Value")]
                return (
                    f"📋 Retention Strategy:\n"
                    f"  • {len(at_risk):,} high-value customers haven't bought in 90+ days — send win-back campaigns.\n"
                    f"  • Offer Medium Value customers loyalty rewards to upgrade them.\n"
                    f"  • Use personalised discounts for Low Value customers to increase frequency."
                )

            if any(kw in q for kw in ["profitable", "most value", "best segment"]):
                seg = df.groupby("Segment")["CLV"].mean().idxmax()
                val = df.groupby("Segment")["CLV"].mean().max()
                return f"💎 Most profitable segment: **{seg}** (avg CLV = ${val:,.0f})"

            if any(kw in q for kw in ["channel", "platform"]):
                ch  = df.groupby("Channel")["CLV"].mean().idxmax()
                val = df.groupby("Channel")["CLV"].mean().max()
                return f"📡 Best channel: **{ch}** with avg CLV = ${val:,.0f}"

            if any(kw in q for kw in ["segment", "distribution"]):
                dist = df["Segment"].value_counts()
                rows = "\n".join(f"  • {s}: {c:,}" for s, c in dist.items())
                return f"📊 Segment distribution:\n{rows}"

        return (
            "I can answer questions about customer segments, top customers, "
            "retention strategies, and channel performance. Please load the "
            "dataset and try again, or set an LLM API key for richer answers."
        )

    # ── Public Interface ──────────────────────────────────────────────────────
    def ask(self, question: str) -> str:
        """Main method: retrieve context → call LLM → return answer."""
        context = self._retrieve(question) if self._ready else ""

        system_prompt = (
            "You are an expert Customer Analytics AI advisor embedded in a CLV dashboard. "
            "Use the provided context (from a real customer dataset) to give specific, "
            "data-driven answers. Be concise, insightful, and business-focused. "
            "If numbers are available, use them. Respond in plain text (no markdown)."
        )

        if context:
            user_msg = f"Context from the customer dataset:\n\n{context}\n\nQuestion: {question}"
        else:
            user_msg = question

        return self._call_llm(system_prompt, user_msg)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Quick smoke-test without a real dataset
    bot = CLVChatbot()
    qs  = [
        "Who are the top customers?",
        "How can we improve retention?",
        "Which segment is most profitable?",
    ]
    for q in qs:
        print(f"\nQ: {q}")
        print(f"A: {bot.ask(q)}")
