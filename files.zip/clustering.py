"""
clustering.py
=============
K-Means customer segmentation on RFM + CLV features.
Labels segments as High / Medium / Low value.
Generates a 2-D scatter visualisation (PCA projection).
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.cluster        import KMeans
from sklearn.decomposition  import PCA
from sklearn.preprocessing  import MinMaxScaler
import joblib

MODEL_DIR  = Path("models")
OUTPUT_DIR = Path("outputs")

# Features used for clustering (RFM-like)
CLUSTER_FEATURES = ["RFM_Score", "MonthlySpend", "Tenure", "Frequency", "Recency"]


# ─────────────────────────────────────────────────────────────────────────────
def segment_customers(df: pd.DataFrame, n_clusters: int = 3) -> pd.DataFrame:
    """
    Run K-Means with n_clusters and attach human-readable segment labels.
    Returns the DataFrame with two new columns:
      - Cluster      : integer cluster id (0,1,2)
      - Segment      : "High Value" / "Medium Value" / "Low Value"
      - Offer        : personalised offer string
    """
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # ── Scale clustering features ────────────────────────────────────────────
    X = df[CLUSTER_FEATURES].copy().fillna(df[CLUSTER_FEATURES].median())
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)

    # ── Fit K-Means ──────────────────────────────────────────────────────────
    print(f"🔵  Fitting K-Means (k={n_clusters}) …")
    km = KMeans(n_clusters=n_clusters, n_init=15, random_state=42)
    km.fit(X_scaled)
    df = df.copy()
    df["Cluster"] = km.labels_

    # ── Map clusters to meaningful names by average CLV ──────────────────────
    cluster_avg_clv = df.groupby("Cluster")["CLV"].mean().sort_values(ascending=False)
    rank_to_label   = {rank: label for rank, label in enumerate(["High Value", "Medium Value", "Low Value"])}
    cluster_to_label = {cluster: rank_to_label[rank] for rank, cluster in enumerate(cluster_avg_clv.index)}
    df["Segment"]   = df["Cluster"].map(cluster_to_label)

    # ── Personalised offers ───────────────────────────────────────────────────
    offer_map = {
        "High Value":   "💳 Premium Credit Card + Exclusive Rewards",
        "Medium Value": "💰 Cashback Offers + Loyalty Points",
        "Low Value":    "🏷️  Seasonal Discounts + Re-engagement Voucher",
    }
    df["Offer"] = df["Segment"].map(offer_map)

    # ── Save model ────────────────────────────────────────────────────────────
    joblib.dump(km, MODEL_DIR / "kmeans.pkl")
    print(f"💾  K-Means saved → {MODEL_DIR / 'kmeans.pkl'}")

    _print_segment_summary(df)
    return df, km, X_scaled


# ─────────────────────────────────────────────────────────────────────────────
def _print_segment_summary(df: pd.DataFrame):
    summary = (
        df.groupby("Segment")
          .agg(Count=("CustomerID", "count"),
               Avg_CLV=("CLV", "mean"),
               Avg_Spend=("MonthlySpend", "mean"),
               Avg_Tenure=("Tenure", "mean"))
          .round(2)
    )
    print("\n📊  Segment Summary:\n", summary.to_string())


# ─────────────────────────────────────────────────────────────────────────────
def plot_clusters(df: pd.DataFrame, X_scaled: np.ndarray, save: bool = True) -> plt.Figure:
    """
    PCA → 2-D scatter coloured by segment.
    """
    pca   = PCA(n_components=2, random_state=42)
    coords = pca.fit_transform(X_scaled)

    palette = {
        "High Value":   "#ffd700",   # gold
        "Medium Value": "#4fc3f7",   # sky blue
        "Low Value":    "#ef5350",   # coral
    }

    fig, ax = plt.subplots(figsize=(10, 7))
    fig.patch.set_facecolor("#0f1117")
    ax.set_facecolor("#1a1a2e")

    for segment, colour in palette.items():
        mask = df["Segment"] == segment
        ax.scatter(
            coords[mask, 0], coords[mask, 1],
            c=colour, label=segment, alpha=0.45, s=8, edgecolors="none"
        )

    ax.set_title("Customer Segments  (PCA projection)", color="white", fontsize=14, pad=12)
    ax.set_xlabel("Principal Component 1", color="#aaaaaa")
    ax.set_ylabel("Principal Component 2", color="#aaaaaa")
    ax.tick_params(colors="#666666")
    ax.spines[:].set_color("#333333")
    legend = ax.legend(fontsize=11, framealpha=0.2, labelcolor="white")
    legend.get_frame().set_facecolor("#111111")

    plt.tight_layout()

    if save:
        path = OUTPUT_DIR / "clusters.png"
        fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
        print(f"📊  Cluster plot saved → {path}")

    return fig


# ─────────────────────────────────────────────────────────────────────────────
def generate_insights(df: pd.DataFrame) -> list[str]:
    """
    Auto-generate textual business insights from the segmented DataFrame.
    Returns a list of insight strings (used in Streamlit & chatbot context).
    """
    insights = []

    total    = len(df)
    seg_dist = df["Segment"].value_counts()

    for seg, count in seg_dist.items():
        pct      = count / total * 100
        avg_clv  = df[df["Segment"] == seg]["CLV"].mean()
        insights.append(
            f"📌 **{seg}**: {count:,} customers ({pct:.1f}%) | Avg CLV = ${avg_clv:,.0f}"
        )

    top_channel = df.groupby("Channel")["CLV"].mean().idxmax()
    insights.append(f"📡 **Top Revenue Channel**: {top_channel} (highest avg CLV)")

    top_age_group = pd.cut(df["Age"], bins=[18, 30, 45, 60, 75],
                           labels=["18-30", "31-45", "46-60", "61-75"])
    df_copy = df.copy()
    df_copy["AgeGroup"] = top_age_group
    best_age = df_copy.groupby("AgeGroup", observed=True)["CLV"].mean().idxmax()
    insights.append(f"🎂 **Most Valuable Age Group**: {best_age} years")

    high_clv_thresh = df["CLV"].quantile(0.9)
    top10_pct       = (df["CLV"] >= high_clv_thresh).sum() / total * 100
    insights.append(
        f"💎 Top 10% of customers (CLV ≥ ${high_clv_thresh:,.0f}) drive disproportionate revenue"
    )

    churn_risk = df[(df["Recency"] > 180) & (df["Segment"] == "High Value")]
    insights.append(
        f"⚠️  {len(churn_risk):,} **High Value customers** haven't purchased in 6+ months — churn risk!"
    )

    rfm_corr = df["RFM_Score"].corr(df["CLV"])
    insights.append(f"📈 RFM Score ↔ CLV correlation: **{rfm_corr:.2f}** (strong predictor)")

    return insights


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    from preprocessing import run_pipeline
    _, _, _, _, df, _ = run_pipeline()
    df_seg, km, X_sc = segment_customers(df)
    plot_clusters(df_seg, X_sc)
    insights = generate_insights(df_seg)
    print("\n🔍  Insights:")
    for i in insights:
        print(" ", i)
