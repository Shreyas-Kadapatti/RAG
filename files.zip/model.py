"""
model.py
========
Trains three regression models to predict Customer Lifetime Value (CLV):
  1. Linear Regression   – simple baseline
  2. Random Forest       – ensemble, handles non-linearity well
  3. XGBoost             – gradient boosting, typically best performer

Evaluation metrics: RMSE and R²
Saves the best model to models/best_model.pkl
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")           # headless rendering for Streamlit
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.linear_model  import LinearRegression
from sklearn.ensemble      import RandomForestRegressor
from sklearn.metrics       import mean_squared_error, r2_score
from xgboost               import XGBRegressor
import joblib

MODEL_DIR  = Path("models")
OUTPUT_DIR = Path("outputs")


# ─────────────────────────────────────────────────────────────────────────────
def build_models() -> dict:
    """Return a dict of {name: unfitted model} for easy iteration."""
    return {
        "Linear Regression": LinearRegression(),
        "Random Forest": RandomForestRegressor(
            n_estimators=200, max_depth=10, n_jobs=-1, random_state=42
        ),
        "XGBoost": XGBRegressor(
            n_estimators=300, max_depth=6, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            random_state=42, verbosity=0, n_jobs=-1,
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
def train_and_evaluate(X_train, X_test, y_train, y_test) -> pd.DataFrame:
    """
    Fit every model, compute RMSE & R², save each model,
    return a results DataFrame and the best model name.
    """
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    models  = build_models()
    results = []

    for name, model in models.items():
        print(f"🏋️  Training {name} …")
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        r2   = r2_score(y_test, y_pred)

        results.append({"Model": name, "RMSE": round(rmse, 2), "R²": round(r2, 4)})
        print(f"   RMSE={rmse:,.2f}   R²={r2:.4f}")

        # Persist each model
        safe_name = name.lower().replace(" ", "_")
        joblib.dump(model, MODEL_DIR / f"{safe_name}.pkl")

    results_df = pd.DataFrame(results).sort_values("RMSE")
    best_model_name = results_df.iloc[0]["Model"]

    # Copy best model to a well-known path
    safe_best = best_model_name.lower().replace(" ", "_")
    import shutil
    shutil.copy(MODEL_DIR / f"{safe_best}.pkl", MODEL_DIR / "best_model.pkl")
    print(f"\n🏆  Best model: {best_model_name}  (saved as best_model.pkl)")

    return results_df, best_model_name, models


# ─────────────────────────────────────────────────────────────────────────────
def plot_model_comparison(results_df: pd.DataFrame, save: bool = True) -> plt.Figure:
    """
    Side-by-side bar chart: RMSE (lower = better) and R² (higher = better).
    Returns the matplotlib Figure so Streamlit can display it directly.
    """
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.patch.set_facecolor("#0f1117")
    colors = ["#4fc3f7", "#81c784", "#ffb74d"]

    # ── RMSE ─────────────────────────────────────────────────────────────────
    ax1 = axes[0]
    ax1.set_facecolor("#1e1e2e")
    bars = ax1.bar(results_df["Model"], results_df["RMSE"], color=colors, edgecolor="none", width=0.5)
    ax1.set_title("RMSE  (lower is better)", color="white", fontsize=13, pad=12)
    ax1.set_ylabel("RMSE", color="#aaaaaa")
    ax1.tick_params(colors="white")
    ax1.spines[:].set_visible(False)
    ax1.set_xticklabels(results_df["Model"], rotation=12, color="white")
    for bar, val in zip(bars, results_df["RMSE"]):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
                 f"{val:,.0f}", ha="center", va="bottom", color="white", fontsize=10)

    # ── R² ───────────────────────────────────────────────────────────────────
    ax2 = axes[1]
    ax2.set_facecolor("#1e1e2e")
    bars2 = ax2.bar(results_df["Model"], results_df["R²"], color=colors, edgecolor="none", width=0.5)
    ax2.set_title("R²  (higher is better)", color="white", fontsize=13, pad=12)
    ax2.set_ylabel("R²", color="#aaaaaa")
    ax2.tick_params(colors="white")
    ax2.spines[:].set_visible(False)
    ax2.set_ylim(0, 1.05)
    ax2.set_xticklabels(results_df["Model"], rotation=12, color="white")
    for bar, val in zip(bars2, results_df["R²"]):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                 f"{val:.3f}", ha="center", va="bottom", color="white", fontsize=10)

    plt.suptitle("Model Comparison – CLV Prediction", color="white", fontsize=15, y=1.02)
    plt.tight_layout()

    if save:
        path = OUTPUT_DIR / "model_comparison.png"
        fig.savefig(path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
        print(f"📊  Chart saved → {path}")

    return fig


# ─────────────────────────────────────────────────────────────────────────────
def get_feature_importance(model, feature_names: list) -> pd.DataFrame:
    """Return feature importances for tree-based models (RF / XGBoost)."""
    if hasattr(model, "feature_importances_"):
        imp = pd.DataFrame({
            "Feature":    feature_names,
            "Importance": model.feature_importances_,
        }).sort_values("Importance", ascending=False)
        return imp
    return pd.DataFrame()


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    from preprocessing import run_pipeline
    X_train, X_test, y_train, y_test, df, scaler = run_pipeline()
    results_df, best_name, trained_models = train_and_evaluate(X_train, X_test, y_train, y_test)
    print("\n📋  Results:\n", results_df.to_string(index=False))
    plot_model_comparison(results_df)
