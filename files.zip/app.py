"""
app.py
======
Streamlit dashboard for the AI CLV & Personalization Engine.

Sections:
  1. 📂 Upload Dataset (or auto-generate)
  2. 📊 CLV Predictions & Model Comparison
  3. 🔵 Customer Segments & Clusters
  4. 💡 Business Insights
  5. 🎁 Personalized Offers
  6. 🤖 GenAI Chatbot

Run:
  streamlit run app.py
"""

import os
import io
import time
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import streamlit as st
import joblib
from pathlib import Path

# ── Local modules ─────────────────────────────────────────────────────────────
from data_generation import generate_dataset
from preprocessing   import handle_missing, encode_categoricals, feature_engineering, \
                            scale_features, FEATURE_COLS
from model           import train_and_evaluate, plot_model_comparison, get_feature_importance
from clustering      import segment_customers, plot_clusters, generate_insights
from chatbot         import CLVChatbot

# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title  = "AI CLV Engine",
    page_icon   = "💎",
    layout      = "wide",
    initial_sidebar_state = "expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* Dark background */
  .main { background-color: #0f1117; }
  .block-container { padding-top: 1.5rem; }

  /* Metric cards */
  [data-testid="metric-container"] {
      background: linear-gradient(135deg, #1e1e2e, #2a2a3e);
      border: 1px solid #333355;
      border-radius: 12px;
      padding: 12px 16px;
  }

  /* Section headers */
  h2 { color: #4fc3f7 !important; }
  h3 { color: #81c784 !important; }

  /* Chat messages */
  .chat-user { background:#1e3a5f; border-radius:10px; padding:10px 14px; margin:6px 0; }
  .chat-bot  { background:#1a2e1a; border-radius:10px; padding:10px 14px; margin:6px 0; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Session state helpers
# ─────────────────────────────────────────────────────────────────────────────
def _ss(key, default=None):
    if key not in st.session_state:
        st.session_state[key] = default
    return st.session_state[key]


# ─────────────────────────────────────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("💎 CLV Engine")
    st.caption("AI-powered Customer Lifetime Value & Personalization")
    st.divider()

    st.subheader("🔑 API Keys (optional)")
    anthropic_key = st.text_input("Anthropic API Key", type="password",
                                   help="Powers the GenAI chatbot (Claude)")
    openai_key    = st.text_input("OpenAI API Key", type="password",
                                   help="Fallback LLM for chatbot")
    if anthropic_key:
        os.environ["ANTHROPIC_API_KEY"] = anthropic_key
    if openai_key:
        os.environ["OPENAI_API_KEY"] = openai_key

    st.divider()
    st.subheader("⚙️ Settings")
    n_rows     = st.slider("Dataset size", 10_000, 100_000, 50_000, step=10_000)
    n_clusters = st.slider("K-Means clusters", 2, 5, 3)
    run_btn    = st.button("🚀 Generate & Run Pipeline", use_container_width=True, type="primary")
    st.divider()
    st.caption("Built with Streamlit · scikit-learn · XGBoost · FAISS")


# ─────────────────────────────────────────────────────────────────────────────
# TABS
# ─────────────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📂 Data",
    "📊 Predictions",
    "🔵 Segments",
    "💡 Insights",
    "🎁 Offers",
    "🤖 Chatbot",
])


# ═════════════════════════════════════════════════════════════════════════════
# TAB 1 – Data
# ═════════════════════════════════════════════════════════════════════════════
with tab1:
    st.header("📂 Dataset")

    col_upload, col_gen = st.columns([1, 1])

    with col_upload:
        st.subheader("Upload your own CSV")
        uploaded = st.file_uploader("Upload CSV", type="csv", label_visibility="collapsed")
        if uploaded:
            df_raw = pd.read_csv(uploaded)
            st.session_state["df_raw"] = df_raw
            st.success(f"✅ Loaded {len(df_raw):,} rows")

    with col_gen:
        st.subheader("Or auto-generate synthetic data")
        if st.button("🎲 Generate Dataset", use_container_width=True) or run_btn:
            with st.spinner(f"Generating {n_rows:,} synthetic customers …"):
                df_raw = generate_dataset(n_rows)
                st.session_state["df_raw"] = df_raw
                st.success(f"✅ Generated {len(df_raw):,} rows")

    if "df_raw" in st.session_state:
        df_raw = st.session_state["df_raw"]
        st.subheader("Preview")
        st.dataframe(df_raw.head(200), use_container_width=True, height=300)

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Customers", f"{len(df_raw):,}")
        c2.metric("Avg CLV",         f"${df_raw['CLV'].mean():,.0f}")
        c3.metric("Avg Age",         f"{df_raw['Age'].mean():.1f}")
        c4.metric("Channels",        df_raw["Channel"].nunique())

        st.subheader("Distribution")
        fig, axes = plt.subplots(1, 3, figsize=(14, 4))
        fig.patch.set_facecolor("#0f1117")
        for ax, col, color in zip(axes, ["CLV", "Income", "Spend"], ["#4fc3f7","#81c784","#ffb74d"]):
            ax.set_facecolor("#1e1e2e")
            ax.hist(df_raw[col].dropna(), bins=60, color=color, edgecolor="none", alpha=0.8)
            ax.set_title(col, color="white")
            ax.tick_params(colors="#aaaaaa")
            ax.spines[:].set_visible(False)
        plt.tight_layout()
        st.pyplot(fig)
    else:
        st.info("👈 Upload a CSV or click 'Generate Dataset' to get started.")


# ═════════════════════════════════════════════════════════════════════════════
# PIPELINE (triggered by Run button or individual tabs)
# ═════════════════════════════════════════════════════════════════════════════
def run_full_pipeline(df_raw, n_clusters):
    """Preprocess → train models → segment → build chatbot."""

    progress = st.progress(0, "Starting pipeline …")

    # Preprocessing
    progress.progress(10, "Preprocessing …")
    df = handle_missing(df_raw.copy())
    df = encode_categoricals(df)
    df = feature_engineering(df)
    X, y, scaler = scale_features(df, fit=True)
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model training
    progress.progress(35, "Training models …")
    results_df, best_name, trained_models = train_and_evaluate(X_train, X_test, y_train, y_test)

    # Add CLV predictions back
    progress.progress(60, "Generating predictions …")
    best_model  = trained_models[best_name]
    X_all, _, _ = scale_features(df, fit=False)
    df["CLV_Pred"] = best_model.predict(X_all).round(2)

    # Clustering
    progress.progress(75, "Segmenting customers …")
    df_seg, km, X_sc = segment_customers(df, n_clusters)

    # Insights
    progress.progress(90, "Generating insights …")
    insights = generate_insights(df_seg)

    # Chatbot
    progress.progress(95, "Initialising chatbot …")
    chatbot  = CLVChatbot(df=df_seg, insights=insights)

    progress.progress(100, "✅ Done!")
    time.sleep(0.3)
    progress.empty()

    return df_seg, results_df, best_name, trained_models, insights, chatbot, X_sc


if run_btn and "df_raw" in st.session_state:
    with st.spinner("Running full pipeline …"):
        (df_seg, results_df, best_name,
         trained_models, insights, chatbot, X_sc) = run_full_pipeline(
             st.session_state["df_raw"], n_clusters
         )
        st.session_state.update({
            "df_seg":         df_seg,
            "results_df":     results_df,
            "best_name":      best_name,
            "trained_models": trained_models,
            "insights":       insights,
            "chatbot":        chatbot,
            "X_sc":           X_sc,
        })
        st.toast("✅ Pipeline complete!", icon="🎉")


# ═════════════════════════════════════════════════════════════════════════════
# TAB 2 – Predictions
# ═════════════════════════════════════════════════════════════════════════════
with tab2:
    st.header("📊 CLV Predictions & Model Comparison")

    if "results_df" not in st.session_state:
        st.info("👈 Click **Generate & Run Pipeline** in the sidebar to train models.")
    else:
        results_df     = st.session_state["results_df"]
        best_name      = st.session_state["best_name"]
        trained_models = st.session_state["trained_models"]
        df_seg         = st.session_state["df_seg"]

        # Metrics row
        c1, c2, c3 = st.columns(3)
        best_row = results_df[results_df["Model"] == best_name].iloc[0]
        c1.metric("🏆 Best Model",   best_name)
        c2.metric("RMSE",            f"{best_row['RMSE']:,}")
        c3.metric("R²",              f"{best_row['R²']:.4f}")

        st.subheader("Model Comparison")
        fig = plot_model_comparison(results_df, save=False)
        st.pyplot(fig)

        st.subheader("All Models")
        st.dataframe(results_df.style.highlight_min("RMSE", color="#2d4f2d")
                                      .highlight_max("R²",   color="#2d4f2d"),
                     use_container_width=True)

        st.subheader("Feature Importance (Best Model)")
        best_mdl = trained_models[best_name]
        fi = get_feature_importance(best_mdl, FEATURE_COLS)
        if not fi.empty:
            fig2, ax = plt.subplots(figsize=(10, 5))
            fig2.patch.set_facecolor("#0f1117")
            ax.set_facecolor("#1e1e2e")
            fi_top = fi.head(10)
            ax.barh(fi_top["Feature"], fi_top["Importance"], color="#4fc3f7", edgecolor="none")
            ax.set_title("Top 10 Features", color="white")
            ax.tick_params(colors="white")
            ax.spines[:].set_visible(False)
            ax.invert_yaxis()
            plt.tight_layout()
            st.pyplot(fig2)

        st.subheader("Sample Predictions vs Actual")
        sample = df_seg[["CustomerID","CLV","CLV_Pred","Segment"]].sample(20, random_state=1)
        st.dataframe(sample.style.format({"CLV": "${:,.2f}", "CLV_Pred": "${:,.2f}"}),
                     use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# TAB 3 – Segments
# ═════════════════════════════════════════════════════════════════════════════
with tab3:
    st.header("🔵 Customer Segmentation")

    if "df_seg" not in st.session_state:
        st.info("👈 Run the pipeline first.")
    else:
        df_seg = st.session_state["df_seg"]
        X_sc   = st.session_state["X_sc"]

        # Segment counts
        col_a, col_b, col_c = st.columns(3)
        for col, seg, icon in zip(
            [col_a, col_b, col_c],
            ["High Value", "Medium Value", "Low Value"],
            ["💎", "💰", "🏷️"],
        ):
            count = (df_seg["Segment"] == seg).sum()
            avg   = df_seg[df_seg["Segment"] == seg]["CLV"].mean()
            col.metric(f"{icon} {seg}", f"{count:,}", f"Avg CLV ${avg:,.0f}")

        st.subheader("Cluster Plot (PCA 2-D)")
        fig = plot_clusters(df_seg, X_sc, save=False)
        st.pyplot(fig)

        st.subheader("Segment Statistics")
        summary = (
            df_seg.groupby("Segment")
                  .agg(
                      Customers   = ("CustomerID",    "count"),
                      Avg_CLV     = ("CLV",           "mean"),
                      Avg_Spend   = ("MonthlySpend",  "mean"),
                      Avg_Freq    = ("Frequency",     "mean"),
                      Avg_Tenure  = ("Tenure",        "mean"),
                  )
                  .round(2)
                  .reset_index()
        )
        st.dataframe(summary.style.format({
            "Avg_CLV":   "${:,.0f}",
            "Avg_Spend": "${:,.0f}",
        }), use_container_width=True)

        st.subheader("CLV by Channel & Segment")
        pivot = df_seg.pivot_table(values="CLV", index="Segment", columns="Channel", aggfunc="mean").round(0)
        st.dataframe(pivot.style.background_gradient(cmap="Blues"), use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# TAB 4 – Insights
# ═════════════════════════════════════════════════════════════════════════════
with tab4:
    st.header("💡 Automated Business Insights")

    if "insights" not in st.session_state:
        st.info("👈 Run the pipeline first.")
    else:
        insights = st.session_state["insights"]
        for ins in insights:
            st.markdown(f"> {ins}")

        st.subheader("CLV Distribution by Segment")
        df_seg = st.session_state["df_seg"]
        fig, ax = plt.subplots(figsize=(10, 5))
        fig.patch.set_facecolor("#0f1117")
        ax.set_facecolor("#1e1e2e")
        colors = {"High Value": "#ffd700", "Medium Value": "#4fc3f7", "Low Value": "#ef5350"}
        for seg, col in colors.items():
            data = df_seg[df_seg["Segment"] == seg]["CLV"]
            ax.hist(data, bins=60, alpha=0.6, color=col, label=seg, edgecolor="none")
        ax.set_title("CLV Distribution by Segment", color="white")
        ax.set_xlabel("CLV ($)", color="#aaaaaa")
        ax.tick_params(colors="#aaaaaa")
        ax.spines[:].set_visible(False)
        legend = ax.legend(labelcolor="white", framealpha=0.2)
        legend.get_frame().set_facecolor("#111111")
        plt.tight_layout()
        st.pyplot(fig)


# ═════════════════════════════════════════════════════════════════════════════
# TAB 5 – Offers
# ═════════════════════════════════════════════════════════════════════════════
with tab5:
    st.header("🎁 Personalised Offer Engine")

    if "df_seg" not in st.session_state:
        st.info("👈 Run the pipeline first.")
    else:
        df_seg = st.session_state["df_seg"]

        st.subheader("Offer Lookup")
        cust_id = st.selectbox("Select a Customer", df_seg["CustomerID"].sample(100, random_state=7).tolist())
        if cust_id:
            row = df_seg[df_seg["CustomerID"] == cust_id].iloc[0]
            col1, col2, col3 = st.columns(3)
            col1.metric("Segment", row["Segment"])
            col2.metric("CLV",     f"${row['CLV']:,.0f}")
            col3.metric("Channel", row["Channel"])
            st.success(f"**Recommended Offer:** {row['Offer']}")

        st.divider()
        st.subheader("Offers by Segment")
        for seg, offer in [
            ("High Value",   "💳 Premium Credit Card + Exclusive Rewards"),
            ("Medium Value", "💰 Cashback Offers + Loyalty Points"),
            ("Low Value",    "🏷️  Seasonal Discounts + Re-engagement Voucher"),
        ]:
            count = (df_seg["Segment"] == seg).sum()
            with st.expander(f"{seg}  ·  {count:,} customers"):
                st.markdown(f"**Offer:** {offer}")
                sub = df_seg[df_seg["Segment"] == seg].sample(min(5, count), random_state=42)
                st.dataframe(sub[["CustomerID", "Age", "Income", "CLV", "Channel"]].reset_index(drop=True),
                             use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# TAB 6 – Chatbot
# ═════════════════════════════════════════════════════════════════════════════
with tab6:
    st.header("🤖 GenAI Customer Analytics Advisor")

    if "chatbot" not in st.session_state:
        st.info("👈 Run the pipeline first to initialise the chatbot.")
    else:
        chatbot = st.session_state["chatbot"]

        # Suggested questions
        st.subheader("Try asking …")
        suggestions = [
            "Who are the top 5 customers?",
            "How can we improve retention?",
            "Which segment is most profitable?",
            "What channel drives the most value?",
            "How many customers are at churn risk?",
        ]
        cols = st.columns(len(suggestions))
        for col, q in zip(cols, suggestions):
            if col.button(q, use_container_width=True):
                st.session_state["chat_input_prefill"] = q

        st.divider()

        # Chat history
        if "chat_history" not in st.session_state:
            st.session_state["chat_history"] = []

        for msg in st.session_state["chat_history"]:
            role_class = "chat-user" if msg["role"] == "user" else "chat-bot"
            icon       = "🧑" if msg["role"] == "user" else "🤖"
            st.markdown(
                f'<div class="{role_class}">{icon} {msg["content"]}</div>',
                unsafe_allow_html=True,
            )

        # Input
        prefill = st.session_state.pop("chat_input_prefill", "")
        question = st.chat_input("Ask anything about your customers …")
        if prefill and not question:
            question = prefill

        if question:
            st.session_state["chat_history"].append({"role": "user", "content": question})
            with st.spinner("Thinking …"):
                answer = chatbot.ask(question)
            st.session_state["chat_history"].append({"role": "assistant", "content": answer})
            st.rerun()
